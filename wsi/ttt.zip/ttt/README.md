# Tic-Tac-Toe Implementation

This is a simple implementation of the classic game Tic-Tac-Toe in Python.

## Contributors

- Grzegorz Kaczor: Developed the initial version of the program.
- Katarzyna Nałęcz-Charkiewicz: Adapted the code for use in the completion of task 3 in the subject of WSI.
